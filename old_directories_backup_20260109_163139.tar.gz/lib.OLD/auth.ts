/**
 * NextAuth Configuration
 * Authentication with credentials and organization context
 */

import { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import prisma from "@/lib/prisma";
import { compare } from "bcryptjs";

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const user = await prisma.user.findUnique({
          where: { email: credentials.email },
          include: {
            organizationMemberships: {
              where: { isActive: true },
              include: {
                organization: true,
              },
              take: 1,
            },
          },
        });

        if (!user || !user.password || !user.isActive) {
          return null;
        }

        const isPasswordValid = await compare(
          credentials.password,
          user.password
        );

        if (!isPasswordValid) {
          return null;
        }

        // Get the user's primary organization
        const primaryOrg = user.organizationMemberships[0];

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          image: user.image,
          role: user.role,
          organizationId: primaryOrg?.organizationId,
        };
      },
    }),
  ],
  session: {
    strategy: "jwt",
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role || "USER";
        token.organizationId = user.organizationId || "";

        // Load organizations
        const memberships = await prisma.organizationMember.findMany({
          where: {
            userId: user.id,
            isActive: true,
          },
          include: {
            organization: true,
          },
        });

        token.organizations = memberships.map((m) => ({
          id: m.organizationId,
          name: m.organization.name,
          role: m.role,
          slug: m.organization.slug,
        }));
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id;
        session.user.role = token.role;
        session.user.organizationId = token.organizationId;
        session.user.organizations = token.organizations;
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
};
