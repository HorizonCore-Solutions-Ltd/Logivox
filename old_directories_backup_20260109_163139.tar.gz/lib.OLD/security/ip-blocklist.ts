/**
 * IP Blocklist Manager
 * Automatic blocking of malicious IPs
 */

interface AttackAttempt {
  type: string;
  patterns?: string[];
  path: string;
  timestamp: Date;
}

interface BlockedIP {
  ip: string;
  reason: string;
  blockedAt: Date;
  expiresAt?: Date;
  violations: number;
  attacks: AttackAttempt[];
}

export class IPBlocklist {
  private blocklist = new Map<string, BlockedIP>();
  private violations = new Map<string, number>();

  // Configurable thresholds
  private readonly VIOLATION_THRESHOLD = 10; // Block after 10 violations
  private readonly BLOCK_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours
  private readonly PERMANENT_BLOCK_THRESHOLD = 50; // Permanent block after 50 violations

  constructor() {
    // Cleanup expired blocks periodically
    setInterval(() => this.cleanupExpiredBlocks(), 60 * 60 * 1000); // Every hour
  }

  /**
   * Check if an IP is blocked
   */
  async isBlocked(ip: string): Promise<boolean> {
    const blocked = this.blocklist.get(ip);

    if (!blocked) {
      return false;
    }

    // Check if block has expired
    if (blocked.expiresAt && new Date() > blocked.expiresAt) {
      this.blocklist.delete(ip);
      return false;
    }

    return true;
  }

  /**
   * Record a rate limit violation
   */
  async recordViolation(ip: string) {
    const currentViolations = this.violations.get(ip) || 0;
    const newViolations = currentViolations + 1;

    this.violations.set(ip, newViolations);

    // Auto-block if threshold exceeded
    if (newViolations >= this.VIOLATION_THRESHOLD) {
      await this.blockIP(ip, "Excessive rate limit violations", newViolations);
    }
  }

  /**
   * Record an attack attempt
   */
  async recordAttackAttempt(ip: string, attempt: AttackAttempt) {
    let blocked = this.blocklist.get(ip);

    if (!blocked) {
      // First attack - immediate block
      blocked = {
        ip,
        reason: `Attack attempt: ${attempt.type}`,
        blockedAt: new Date(),
        expiresAt: new Date(Date.now() + this.BLOCK_DURATION_MS),
        violations: 1,
        attacks: [attempt],
      };
    } else {
      // Additional attack - extend block
      blocked.violations++;
      blocked.attacks.push(attempt);

      // Permanent block after threshold
      if (blocked.violations >= this.PERMANENT_BLOCK_THRESHOLD) {
        blocked.expiresAt = undefined; // Permanent
        blocked.reason = `Permanent block: ${blocked.violations} attacks`;
      }
    }

    this.blocklist.set(ip, blocked);

    // Log to database for analysis
    await this.logAttackAttempt(ip, attempt);
  }

  /**
   * Block an IP address
   */
  private async blockIP(ip: string, reason: string, violations: number) {
    const expiresAt =
      violations >= this.PERMANENT_BLOCK_THRESHOLD
        ? undefined // Permanent
        : new Date(Date.now() + this.BLOCK_DURATION_MS);

    this.blocklist.set(ip, {
      ip,
      reason,
      blockedAt: new Date(),
      expiresAt,
      violations,
      attacks: [],
    });

    // Log to database
    await this.logBlock(ip, reason, violations, expiresAt);
  }

  /**
   * Manually unblock an IP (admin action)
   */
  async unblockIP(ip: string) {
    this.blocklist.delete(ip);
    this.violations.delete(ip);
  }

  /**
   * Get blocked IP details
   */
  getBlockDetails(ip: string): BlockedIP | undefined {
    return this.blocklist.get(ip);
  }

  /**
   * Get all blocked IPs
   */
  getAllBlocked(): BlockedIP[] {
    return Array.from(this.blocklist.values());
  }

  /**
   * Get violation count for IP
   */
  getViolations(ip: string): number {
    return this.violations.get(ip) || 0;
  }

  /**
   * Cleanup expired blocks
   */
  private cleanupExpiredBlocks() {
    const now = new Date();

    for (const [ip, blocked] of this.blocklist.entries()) {
      if (blocked.expiresAt && now > blocked.expiresAt) {
        this.blocklist.delete(ip);

        // Also reset violations after block expires
        this.violations.delete(ip);
      }
    }
  }

  /**
   * Log attack attempt to database
   */
  private async logAttackAttempt(ip: string, attempt: AttackAttempt) {
    try {
      await fetch("/api/security/log-attack", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ip,
          type: attempt.type,
          patterns: attempt.patterns,
          path: attempt.path,
          timestamp: attempt.timestamp,
        }),
      });
    } catch (error) {
      console.error("Failed to log attack attempt:", error);
    }
  }

  /**
   * Log IP block to database
   */
  private async logBlock(
    ip: string,
    reason: string,
    violations: number,
    expiresAt?: Date
  ) {
    try {
      await fetch("/api/security/log-block", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ip,
          reason,
          violations,
          expiresAt: expiresAt?.toISOString(),
          permanent: !expiresAt,
        }),
      });
    } catch (error) {
      console.error("Failed to log IP block:", error);
    }
  }

  /**
   * Import blocklist from external source (e.g., shared threat intelligence)
   */
  async importBlocklist(ips: string[], reason: string = "External threat list") {
    for (const ip of ips) {
      await this.blockIP(ip, reason, this.VIOLATION_THRESHOLD);
    }
  }

  /**
   * Export blocklist for sharing/backup
   */
  exportBlocklist(): BlockedIP[] {
    return this.getAllBlocked();
  }
}
