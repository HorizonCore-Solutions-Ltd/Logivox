/**
 * Security Validator
 * Detects and prevents common security attacks
 */

export class SecurityValidator {
  // SQL Injection patterns
  private sqlInjectionPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE)\b)/gi,
    /(\b(UNION|OR|AND)\b.*\b(SELECT|FROM|WHERE)\b)/gi,
    /(--|\/\*|\*\/|;)/g,
    /(\bOR\b\s+\d+\s*=\s*\d+)/gi,
    /('|")\s*(OR|AND)\s*('|")/gi,
  ];

  // XSS patterns
  private xssPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=\s*["'].*["']/gi,
    /<iframe[^>]*>/gi,
    /<embed[^>]*>/gi,
    /<object[^>]*>/gi,
  ];

  // Path traversal patterns
  private pathTraversalPatterns = [
    /\.\.\//g,
    /\.\.\\\/g,
    /%2e%2e%2f/gi,
    /%252e%252e%252f/gi,
  ];

  // Command injection patterns
  private commandInjectionPatterns = [
    /[;&|`$(){}[\]]/g,
    /\bexec\b|\beval\b|\bsystem\b/gi,
  ];

  /**
   * Validate HTTP headers for security issues
   */
  validateHeaders(headers: Headers): string[] {
    const issues: string[] = [];

    // Check for suspicious user agents
    const userAgent = headers.get("user-agent");
    if (userAgent && this.isSuspiciousUserAgent(userAgent)) {
      issues.push("Suspicious user agent detected");
    }

    // Check for invalid content types
    const contentType = headers.get("content-type");
    if (contentType && this.isInvalidContentType(contentType)) {
      issues.push("Invalid content type");
    }

    // Check for oversized headers (potential DoS)
    let totalHeaderSize = 0;
    headers.forEach((value, key) => {
      totalHeaderSize += key.length + value.length;
    });

    if (totalHeaderSize > 100000) {
      // 100KB limit
      issues.push("Headers exceed size limit");
    }

    return issues;
  }

  /**
   * Detect malicious content in request body
   */
  detectMaliciousContent(data: any): string[] {
    const patterns: string[] = [];

    const checkValue = (value: string, path: string = "") => {
      // SQL Injection
      if (this.containsSqlInjection(value)) {
        patterns.push(`SQL injection detected at ${path}`);
      }

      // XSS
      if (this.containsXss(value)) {
        patterns.push(`XSS attempt detected at ${path}`);
      }

      // Path traversal
      if (this.containsPathTraversal(value)) {
        patterns.push(`Path traversal detected at ${path}`);
      }

      // Command injection
      if (this.containsCommandInjection(value)) {
        patterns.push(`Command injection detected at ${path}`);
      }
    };

    const traverse = (obj: any, currentPath: string = "") => {
      if (typeof obj === "string") {
        checkValue(obj, currentPath);
      } else if (Array.isArray(obj)) {
        obj.forEach((item, index) =>
          traverse(item, `${currentPath}[${index}]`)
        );
      } else if (obj && typeof obj === "object") {
        Object.entries(obj).forEach(([key, value]) => {
          const newPath = currentPath ? `${currentPath}.${key}` : key;
          traverse(value, newPath);
        });
      }
    };

    traverse(data);
    return patterns;
  }

  /**
   * Validate API key format
   */
  isValidApiKey(apiKey: string): boolean {
    // API keys should be at least 32 characters and alphanumeric with hyphens
    const apiKeyRegex = /^[A-Za-z0-9_-]{32,}$/;
    return apiKeyRegex.test(apiKey);
  }

  /**
   * Sanitize user input
   */
  sanitizeInput(input: string): string {
    return input
      .replace(/[<>]/g, "") // Remove angle brackets
      .replace(/['"]/g, "&#39;") // Escape quotes
      .replace(/&/g, "&amp;")
      .trim();
  }

  /**
   * Check if value contains SQL injection
   */
  private containsSqlInjection(value: string): boolean {
    return this.sqlInjectionPatterns.some((pattern) => pattern.test(value));
  }

  /**
   * Check if value contains XSS
   */
  private containsXss(value: string): boolean {
    return this.xssPatterns.some((pattern) => pattern.test(value));
  }

  /**
   * Check if value contains path traversal
   */
  private containsPathTraversal(value: string): boolean {
    return this.pathTraversalPatterns.some((pattern) => pattern.test(value));
  }

  /**
   * Check if value contains command injection
   */
  private containsCommandInjection(value: string): boolean {
    return this.commandInjectionPatterns.some((pattern) => pattern.test(value));
  }

  /**
   * Check for suspicious user agents
   */
  private isSuspiciousUserAgent(userAgent: string): boolean {
    const suspiciousPatterns = [
      /bot/i,
      /crawler/i,
      /spider/i,
      /scraper/i,
      /curl/i,
      /wget/i,
      /python-requests/i,
    ];

    return suspiciousPatterns.some((pattern) => pattern.test(userAgent));
  }

  /**
   * Check for invalid content types
   */
  private isInvalidContentType(contentType: string): boolean {
    const validTypes = [
      "application/json",
      "application/x-www-form-urlencoded",
      "multipart/form-data",
      "text/plain",
    ];

    return !validTypes.some((type) => contentType.includes(type));
  }

  /**
   * Generate secure random token
   */
  generateSecureToken(length: number = 32): string {
    const chars =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let token = "";
    const randomValues = new Uint8Array(length);
    crypto.getRandomValues(randomValues);

    for (let i = 0; i < length; i++) {
      token += chars[randomValues[i] % chars.length];
    }

    return token;
  }

  /**
   * Hash password securely
   */
  async hashPassword(password: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hash = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(hash))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  /**
   * Verify password hash
   */
  async verifyPassword(password: string, hash: string): Promise<boolean> {
    const computedHash = await this.hashPassword(password);
    return computedHash === hash;
  }
}
