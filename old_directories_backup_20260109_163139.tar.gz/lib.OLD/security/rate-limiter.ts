/**
 * Rate Limiter Utility
 * Military-grade rate limiting with sliding window algorithm
 */

interface RateLimitConfig {
  windowMs: number;
  maxRequests: number;
}

interface RateLimitResult {
  allowed: boolean;
  limit: number;
  remaining: number;
  resetAt?: number;
  retryAfter?: number;
}

// Rate limit configurations by route type
const RATE_LIMITS: Record<string, RateLimitConfig> = {
  // Authentication endpoints - strict limits
  "/api/auth": { windowMs: 15 * 60 * 1000, maxRequests: 5 }, // 5 per 15 min
  "/api/auth/signin": { windowMs: 15 * 60 * 1000, maxRequests: 5 },
  "/api/auth/signup": { windowMs: 60 * 60 * 1000, maxRequests: 3 }, // 3 per hour

  // Public API - moderate limits
  "/api/public": { windowMs: 60 * 1000, maxRequests: 60 }, // 60 per minute

  // Standard API - generous limits
  "/api": { windowMs: 60 * 1000, maxRequests: 1000 }, // 1000 per minute

  // File uploads - strict limits
  "/api/upload": { windowMs: 60 * 1000, maxRequests: 10 }, // 10 per minute

  // Reports/exports - moderate limits
  "/api/reports": { windowMs: 60 * 1000, maxRequests: 30 }, // 30 per minute
};

export class RateLimiter {
  private store = new Map<
    string,
    { count: number; resetAt: number; violations: number }
  >();

  constructor(private cleanupIntervalMs: number = 60000) {
    // Cleanup expired entries periodically
    setInterval(() => this.cleanup(), cleanupIntervalMs);
  }

  async checkLimit(
    identifier: string,
    path: string,
    method: string
  ): Promise<RateLimitResult> {
    const config = this.getConfigForPath(path);
    const key = `${identifier}:${path}:${method}`;
    const now = Date.now();

    let entry = this.store.get(key);

    // Create new entry if doesn't exist or expired
    if (!entry || now > entry.resetAt) {
      entry = {
        count: 0,
        resetAt: now + config.windowMs,
        violations: entry?.violations || 0,
      };
      this.store.set(key, entry);
    }

    // Check if limit exceeded
    if (entry.count >= config.maxRequests) {
      entry.violations++;
      return {
        allowed: false,
        limit: config.maxRequests,
        remaining: 0,
        resetAt: entry.resetAt,
        retryAfter: Math.ceil((entry.resetAt - now) / 1000),
      };
    }

    // Increment counter
    entry.count++;

    return {
      allowed: true,
      limit: config.maxRequests,
      remaining: config.maxRequests - entry.count,
      resetAt: entry.resetAt,
    };
  }

  private getConfigForPath(path: string): RateLimitConfig {
    // Find most specific matching path
    const matchingPaths = Object.keys(RATE_LIMITS)
      .filter((p) => path.startsWith(p))
      .sort((a, b) => b.length - a.length); // Most specific first

    const matchedPath = matchingPaths[0];
    return RATE_LIMITS[matchedPath] || RATE_LIMITS["/api"];
  }

  private cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.store.entries()) {
      if (now > entry.resetAt + 60000) {
        // Keep for 1 extra minute
        this.store.delete(key);
      }
    }
  }

  // Get violation count for an identifier
  getViolations(identifier: string): number {
    let total = 0;
    for (const [key, entry] of this.store.entries()) {
      if (key.startsWith(identifier)) {
        total += entry.violations;
      }
    }
    return total;
  }

  // Reset violations for identifier (e.g., after successful auth)
  resetViolations(identifier: string) {
    for (const [key, entry] of this.store.entries()) {
      if (key.startsWith(identifier)) {
        entry.violations = 0;
      }
    }
  }
}
