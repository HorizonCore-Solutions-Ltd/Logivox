/**
 * Enhanced CAPA Service with Blockchain Integration
 * Automatically creates blockchain records for all CAPA actions
 */

import prisma from "@/lib/prisma";
import crypto from "crypto";

interface BlockchainOptions {
  enabled?: boolean;
  signature?: string;
}

export class CAPABlockchainService {
  /**
   * Create CAPA with blockchain record
   */
  static async createCAPA(
    organizationId: string,
    userId: string,
    capaData: any,
    options: BlockchainOptions = { enabled: true }
  ) {
    // Create CAPA
    const capa = await prisma.correctivePreventiveAction.create({
      data: capaData,
    });

    // Create blockchain genesis block
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capa.id,
        "CAPA_CREATED",
        {
          capaNumber: capa.capaNumber,
          capaType: capa.capaType,
          problemStatement: capa.problemStatement,
          severity: capa.problemSeverity,
        },
        options.signature
      );
    }

    return capa;
  }

  /**
   * Update CAPA with blockchain record
   */
  static async updateCAPA(
    organizationId: string,
    userId: string,
    capaId: string,
    action: string,
    updateData: any,
    changedData: any,
    options: BlockchainOptions = { enabled: true }
  ) {
    // Update CAPA
    const capa = await prisma.correctivePreventiveAction.update({
      where: { id: capaId },
      data: updateData,
    });

    // Create blockchain record
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capaId,
        action,
        changedData,
        options.signature
      );
    }

    return capa;
  }

  /**
   * Add action to CAPA with blockchain record
   */
  static async addAction(
    organizationId: string,
    userId: string,
    capaId: string,
    actionType: "immediate" | "corrective" | "preventive",
    action: any,
    options: BlockchainOptions = { enabled: true }
  ) {
    const capa = await prisma.correctivePreventiveAction.findUnique({
      where: { id: capaId },
    });

    if (!capa) throw new Error("CAPA not found");

    const actionField =
      actionType === "immediate"
        ? "immediateActions"
        : actionType === "corrective"
        ? "correctiveActions"
        : "preventiveActions";

    const currentActions = ((capa as any)[actionField] as any[]) || [];
    const updatedActions = [...currentActions, action];

    await prisma.correctivePreventiveAction.update({
      where: { id: capaId },
      data: {
        [actionField]: updatedActions as any,
      },
    });

    // Create blockchain record
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capaId,
        `${actionType.toUpperCase()}_ACTION_ADDED`,
        {
          actionType,
          action,
        },
        options.signature
      );
    }

    return updatedActions;
  }

  /**
   * Complete root cause analysis with blockchain record
   */
  static async completeRCA(
    organizationId: string,
    userId: string,
    capaId: string,
    rcaData: any,
    rootCause: string,
    options: BlockchainOptions = { enabled: true }
  ) {
    await prisma.correctivePreventiveAction.update({
      where: { id: capaId },
      data: {
        rootCauseAnalysis: rcaData as any,
        rootCause,
      },
    });

    // Create blockchain record
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capaId,
        "ROOT_CAUSE_COMPLETED",
        {
          method: rcaData.method,
          rootCause,
        },
        options.signature
      );
    }
  }

  /**
   * Verify CAPA effectiveness with blockchain record
   */
  static async verifyEffectiveness(
    organizationId: string,
    userId: string,
    capaId: string,
    verificationData: {
      method: string;
      passed: boolean;
      score: number;
      notes?: string;
    },
    options: BlockchainOptions = { enabled: true }
  ) {
    await prisma.correctivePreventiveAction.update({
      where: { id: capaId },
      data: {
        verificationMethod: verificationData.method,
        verificationDate: new Date(),
        verificationPerformedBy: userId,
        verificationPassed: verificationData.passed,
        effectivenessScore: verificationData.score,
        effectivenessNotes: verificationData.notes,
      },
    });

    // Create blockchain record
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capaId,
        "EFFECTIVENESS_VERIFIED",
        verificationData,
        options.signature
      );
    }
  }

  /**
   * Close CAPA with blockchain record
   */
  static async closeCAPA(
    organizationId: string,
    userId: string,
    capaId: string,
    closureNotes: string,
    options: BlockchainOptions = { enabled: true }
  ) {
    const capa = await prisma.correctivePreventiveAction.update({
      where: { id: capaId },
      data: {
        status: "CLOSED",
        closedDate: new Date(),
        closedBy: userId,
        notes: closureNotes,
      },
    });

    // Create blockchain record
    if (options.enabled) {
      await this.addBlockchainRecord(
        organizationId,
        userId,
        capaId,
        "CAPA_CLOSED",
        {
          closureNotes,
          finalStatus: "CLOSED",
        },
        options.signature
      );
    }

    return capa;
  }

  /**
   * Add blockchain record
   */
  private static async addBlockchainRecord(
    organizationId: string,
    userId: string,
    capaId: string,
    action: string,
    data: any,
    signature?: string
  ) {
    // Get previous block hash
    const lastBlock = await prisma.activityLog.findFirst({
      where: {
        organizationId,
        entityType: "CAPA",
        entityId: capaId,
      },
      orderBy: { createdAt: "desc" },
      take: 1,
    });

    const previousHash = lastBlock
      ? this.generateHash(lastBlock)
      : "0000000000000000000000000000000000000000000000000000000000000000";

    // Create new blockchain record
    const activityLog = await prisma.activityLog.create({
      data: {
        organizationId,
        userId,
        action,
        entityType: "CAPA",
        entityId: capaId,
        metadata: {
          data,
          previousHash,
          signature,
          blockchainEnabled: true,
        },
      },
    });

    // Calculate and store hash
    const blockHash = this.generateHash(activityLog);

    await prisma.activityLog.update({
      where: { id: activityLog.id },
      data: {
        metadata: {
          ...(activityLog.metadata as any),
          hash: blockHash,
        },
      },
    });

    return activityLog;
  }

  /**
   * Generate cryptographic hash for block
   */
  private static generateHash(log: any): string {
    const metadata = (log.metadata as any) || {};
    const data = JSON.stringify({
      timestamp: log.createdAt,
      userId: log.userId,
      action: log.action,
      entityId: log.entityId,
      data: metadata.data,
      previousHash: metadata.previousHash,
    });

    return crypto.createHash("sha256").update(data).digest("hex");
  }

  /**
   * Verify blockchain integrity for a CAPA
   */
  static async verifyBlockchain(organizationId: string, capaId: string) {
    const blocks = await prisma.activityLog.findMany({
      where: {
        organizationId,
        entityType: "CAPA",
        entityId: capaId,
      },
      orderBy: { createdAt: "asc" },
    });

    const tamperedBlocks: number[] = [];
    let previousHash =
      "0000000000000000000000000000000000000000000000000000000000000000";

    for (let i = 0; i < blocks.length; i++) {
      const block = blocks[i];
      const metadata = (block.metadata as any) || {};
      const storedHash = metadata.hash;
      const calculatedHash = this.generateHash(block);

      // Check if hash matches
      if (storedHash !== calculatedHash) {
        tamperedBlocks.push(i + 1);
      }

      // Check if chain is intact
      if (metadata.previousHash !== previousHash) {
        tamperedBlocks.push(i + 1);
      }

      previousHash = storedHash || calculatedHash;
    }

    return {
      isValid: tamperedBlocks.length === 0,
      tamperedBlocks,
      totalBlocks: blocks.length,
      verifiedBlocks: blocks.length - tamperedBlocks.length,
    };
  }

  /**
   * Export blockchain for audit
   */
  static async exportBlockchain(organizationId: string, capaId: string) {
    const capa = await prisma.correctivePreventiveAction.findUnique({
      where: { id: capaId, organizationId },
    });

    const blocks = await prisma.activityLog.findMany({
      where: {
        organizationId,
        entityType: "CAPA",
        entityId: capaId,
      },
      orderBy: { createdAt: "asc" },
      include: {
        user: {
          select: {
            name: true,
            email: true,
          },
        },
      },
    });

    return {
      capaNumber: capa?.capaNumber,
      exportDate: new Date().toISOString(),
      blocks: blocks.map((block, index) => ({
        index: index + 1,
        timestamp: block.createdAt.toISOString(),
        action: block.action,
        user: block.user?.name || "Unknown",
        userEmail: block.user?.email,
        data: (block.metadata as any)?.data,
        hash: (block.metadata as any)?.hash,
        previousHash: (block.metadata as any)?.previousHash,
        signature: (block.metadata as any)?.signature,
      })),
    };
  }
}
